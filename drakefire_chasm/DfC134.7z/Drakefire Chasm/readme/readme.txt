_______________________
	Drakefire Chasm

A seven-day roguelike made by Tanthie in the 7DRL Challenge of 2012. (And updated thereafter.)

Uses libtcod 1.5.1 � Jice & Mingos
http://doryen.eptalys.net/libtcod


Feedback and such welcome at:

* My blog: http://dowhilecompiling.blogspot.com
* Email: contact.tanthie@gmail.com
* Twitter: @TanthieActual
* IRC: QuakeNet - #rgrd


	About the game:

You play as a freshly born wyrmling dragon ('D'), trying to survive and prosper in Drakefire Chasm. Eat lesser beings, hoard riches, defeat your foes, and finally become a Great Wyrm, the most terrifying and noblest of creatures.

Your goal on each level is to get your satiation level to 100% by eating the corpses of your enemies. Once fully satiated, enter the tunnel ('<') to continue onto the next level. Gathering gems ('*') and coins ('$') (autopicked when moving on them) increases your score.

Your dragon ages when entering a new level, gaining bonuses to attributes, more health, and new abilities.


	Controls:

Movement:

 Numpad	  or	Extended vi

 7 8 9		y k u
  \|/		 \|/
 4-5-6		h-.-l
  /|\		 /|\
 1 2 3		b j n

(Arrow keys work for the cardinal directions as well.)

On menus:

dir	move
enter	select

In-game:

w + dir	walkmode (interrupted when there are hostile creatures in sight)
1 to 8	use an ability on the action bar
e or <	eat (when on corpse) or enter (when on a tunnel entrance)
x	examine
a	show the ability screen
o or r	show the dragon orb screen
m	show past messages
v	toggle showing enemies' health (colors their background)
Q	quit
?	show the help screen
F12	toggle fullscreen
PrtScrn	take a screenshot
enter	skip all (more) prompts at once

Targeting:

dir	move the cursor
space	accept
esc	cancel
tab	move cursor onto next target
alt+dir	switch cone or bolt targeting straight toward the direction


	Tips on survival:

* Eating corpses heals you. (Each enemy drops a corpse upon death -- usually hidden under the treasure it dropped as well.)

* Try to avoid open areas.

* Enemies come in three categories: tough, agile, and cunning. The effectiveness of your ability against an enemy depends on how effective the ability's type (Strength, Stamina, or Will) is against the enemy type.

* You are what you eat -- you gain an extra +1 to one attribute when aging, determined by the enemy category you ate most on the level.

* All abilities scale with their respective attribute (and many with your Age as well) doing more damage and covering a larger area.